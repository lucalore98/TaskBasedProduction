clear
clc
% Initialize parameters
theta = 1.0;
kappa = 0.5;
z = 1.2;
alphaVec = [0.1, 0.2, 0.3];
xT = [0.4, 0.5];

% Call unitInputDemand and print the output
labor_demand = TaskBasedProduction.unitInputDemand(theta, kappa, z, alphaVec, xT);
disp('Labor Demand:');
disp(labor_demand);

% Call margProdLabor with labor demand
mpl = TaskBasedProduction.margProdLabor(labor_demand, alphaVec, xT);
disp('Marginal Products of Labor:');
disp(mpl);

% Call margProdLabor with blueprint characteristics
mpl_theta = TaskBasedProduction.margProdLabor2(theta, kappa, z, alphaVec, xT);
disp('Marginal Products of Labor (using blueprint characteristics):');
disp(mpl_theta);

% Call prod_fun with labor demand
[q, xT] = TaskBasedProduction.prod_fun(labor_demand, theta, kappa, z, alphaVec);
disp('Quantity Produced:');
disp(q);
disp('Task Thresholds:');
disp(xT);

% Call elasticity_sub_comp
[epsilon_h_sub, epsilon_h_compl] = TaskBasedProduction.elasticity_sub_comp(xT, labor_demand, q, mpl, theta, kappa, z, alphaVec);

disp('Elasticity of Substitution:');
disp(epsilon_h_sub);
disp('Elasticity of Complementarity:');
disp(epsilon_h_compl);